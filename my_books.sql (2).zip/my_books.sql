-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Feb 05, 2024 at 02:47 AM
-- Server version: 8.0.31
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `my_books`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

DROP TABLE IF EXISTS `books`;
CREATE TABLE IF NOT EXISTS `books` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int NOT NULL,
  `author` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `language` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `name`, `price`, `author`, `created_at`, `updated_at`, `language`, `description`, `image`) VALUES
(30, 'Wish', 345, 'Barabara', '2024-02-03 14:09:03', '2024-02-04 03:01:04', 'English', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam blandit nunc quis nisl volutpat, in ultrices magna consectetur. In hac habitasse platea dictumst. Sed viverra nibh non sem laoreet, quis semper dui imperdiet. Mauris pellentesque vitae sapien a blandit. Integer convallis iaculis nisi et venenatis. Ut cursus velit sem, ut faucibus ipsum egestas rhoncus. Sed pulvinar pretium neque eu eleifend. Maecenas non luctus urna, ut porta leo. Integer consequat metus eu varius interdum. Sed libero enim, eleifend nec urna luctus, rutrum dignissim nibh. Maecenas non nisi mattis, bibendum turpis interdum, lobortis ante. Suspendisse in nulla orci. Suspendisse potenti.', '/book-img/1706989143wish.jpg'),
(29, 'The Last Bear', 456, 'Hannah Gold', '2024-02-03 13:49:42', '2024-02-03 14:53:23', 'English', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam blandit nunc quis nisl volutpat, in ultrices magna consectetur. In hac habitasse platea dictumst. Sed viverra nibh non sem laoreet, quis semper dui imperdiet. Mauris pellentesque vitae sapien a blandit. Integer convallis iaculis nisi et venenatis. Ut cursus velit sem, ut faucibus ipsum egestas rhoncus. Sed pulvinar pretium neque eu eleifend. Maecenas non luctus urna, ut porta leo. Integer consequat metus eu varius interdum. Sed libero enim, eleifend nec urna luctus, rutrum dignissim nibh. Maecenas non nisi mattis, bibendum turpis interdum, lobortis ante. Suspendisse in nulla orci. Suspendisse potenti.', '/book-img/1706989187the-last-bear.jpg'),
(31, 'Harry Potter', 4000, 'J K Rowling', '2024-02-03 14:54:41', '2024-02-03 14:54:41', 'English', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam blandit nunc quis nisl volutpat, in ultrices magna consectetur. In hac habitasse platea dictumst. Sed viverra nibh non sem laoreet, quis semper dui imperdiet. Mauris pellentesque vitae sapien a blandit. Integer convallis iaculis nisi et venenatis. Ut cursus velit sem, ut faucibus ipsum egestas rhoncus. Sed pulvinar pretium neque eu eleifend. Maecenas non luctus urna, ut porta leo. Integer consequat metus eu varius interdum. Sed libero enim, eleifend nec urna luctus, rutrum dignissim nibh. Maecenas non nisi mattis, bibendum turpis interdum, lobortis ante. Suspendisse in nulla orci. Suspendisse potenti.', '/book-img/1706991881harrypoter.jpg'),
(32, 'Ice Breaker', 500, 'Hannah Grace', '2024-02-03 14:55:46', '2024-02-03 14:55:46', 'English', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam blandit nunc quis nisl volutpat, in ultrices magna consectetur. In hac habitasse platea dictumst. Sed viverra nibh non sem laoreet, quis semper dui imperdiet. Mauris pellentesque vitae sapien a blandit. Integer convallis iaculis nisi et venenatis. Ut cursus velit sem, ut faucibus ipsum egestas rhoncus. Sed pulvinar pretium neque eu eleifend. Maecenas non luctus urna, ut porta leo. Integer consequat metus eu varius interdum. Sed libero enim, eleifend nec urna luctus, rutrum dignissim nibh. Maecenas non nisi mattis, bibendum turpis interdum, lobortis ante. Suspendisse in nulla orci. Suspendisse potenti.', '/book-img/1706991946icebreaker.jpg'),
(33, 'No Longer Humans', 200, 'Osamu Dazai', '2024-02-03 14:56:50', '2024-02-03 14:56:50', 'English', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam blandit nunc quis nisl volutpat, in ultrices magna consectetur. In hac habitasse platea dictumst. Sed viverra nibh non sem laoreet, quis semper dui imperdiet. Mauris pellentesque vitae sapien a blandit. Integer convallis iaculis nisi et venenatis. Ut cursus velit sem, ut faucibus ipsum egestas rhoncus. Sed pulvinar pretium neque eu eleifend. Maecenas non luctus urna, ut porta leo. Integer consequat metus eu varius interdum. Sed libero enim, eleifend nec urna luctus, rutrum dignissim nibh. Maecenas non nisi mattis, bibendum turpis interdum, lobortis ante. Suspendisse in nulla orci. Suspendisse potenti.', '/book-img/1706992010no-longer-human.jpg'),
(34, 'Shatter Me', 250, 'Tahereh Mafi', '2024-02-03 14:58:03', '2024-02-03 14:58:03', 'English', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam blandit nunc quis nisl volutpat, in ultrices magna consectetur. In hac habitasse platea dictumst. Sed viverra nibh non sem laoreet, quis semper dui imperdiet. Mauris pellentesque vitae sapien a blandit. Integer convallis iaculis nisi et venenatis. Ut cursus velit sem, ut faucibus ipsum egestas rhoncus. Sed pulvinar pretium neque eu eleifend. Maecenas non luctus urna, ut porta leo. Integer consequat metus eu varius interdum. Sed libero enim, eleifend nec urna luctus, rutrum dignissim nibh. Maecenas non nisi mattis, bibendum turpis interdum, lobortis ante. Suspendisse in nulla orci. Suspendisse potenti.', '/book-img/1706992083shatter me.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `media`
--

DROP TABLE IF EXISTS `media`;
CREATE TABLE IF NOT EXISTS `media` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint UNSIGNED NOT NULL,
  `uuid` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `collection_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mime_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `disk` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `conversions_disk` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size` bigint UNSIGNED NOT NULL,
  `manipulations` json NOT NULL,
  `custom_properties` json NOT NULL,
  `generated_conversions` json NOT NULL,
  `responsive_images` json NOT NULL,
  `order_column` int UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `media_uuid_unique` (`uuid`),
  KEY `media_model_type_model_id_index` (`model_type`,`model_id`),
  KEY `media_order_column_index` (`order_column`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `media`
--

INSERT INTO `media` (`id`, `model_type`, `model_id`, `uuid`, `collection_name`, `name`, `file_name`, `mime_type`, `disk`, `conversions_disk`, `size`, `manipulations`, `custom_properties`, `generated_conversions`, `responsive_images`, `order_column`, `created_at`, `updated_at`) VALUES
(16, 'App\\Models\\Book', 27, 'cf06660f-e6be-4d35-bf14-519050fd60e6', 'image', 'wish', 'wish.jpg', 'image/jpeg', 'public', 'public', 120709, '[]', '[]', '[]', '[]', 1, '2024-02-03 13:30:08', '2024-02-03 13:30:08'),
(13, 'App\\Models\\Book', 23, '85a58be5-62e5-4491-9574-589830a125cc', 'image', 'oACen3HJCZLlr6JoQ62kQdNDybaMDsRwLA9mQ6pa', 'oACen3HJCZLlr6JoQ62kQdNDybaMDsRwLA9mQ6pa.jpg', 'image/jpeg', 'public', 'public', 150478, '[]', '[]', '[]', '[]', 1, '2024-02-03 13:18:24', '2024-02-03 13:18:24'),
(14, 'App\\Models\\Book', 24, '011645fd-39dd-49f6-a029-b23f68761066', 'image', 'KEP5NVONvv5lLKZXQGK3okirLnRfQejC1kbCHMl9', 'KEP5NVONvv5lLKZXQGK3okirLnRfQejC1kbCHMl9.jpg', 'image/jpeg', 'public', 'public', 103339, '[]', '[]', '[]', '[]', 1, '2024-02-03 13:24:17', '2024-02-03 13:24:17'),
(15, 'App\\Models\\Book', 26, '7532180f-4d55-40b7-8189-018e25957f6f', 'image', 'wish', 'wish.jpg', 'image/jpeg', 'public', 'public', 120709, '[]', '[]', '[]', '[]', 1, '2024-02-03 13:29:16', '2024-02-03 13:29:16');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(11, '2014_10_12_000000_create_users_table', 1),
(12, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(13, '2019_08_19_000000_create_failed_jobs_table', 1),
(14, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(15, '2024_01_31_111103_create_books_table', 1),
(16, '2024_01_31_000000_create_media_table', 2),
(17, '2024_02_03_063311_add_column_name_to_books', 3),
(18, '2024_02_03_190627_add_column_to_books', 4),
(19, '2024_02_03_210628_create_orders_table', 5),
(20, '2024_02_03_220615_create_order_items_table', 6),
(21, '2024_02_04_125756_create_queries_table', 7),
(22, '2024_02_04_151704_add_column_to_users', 8),
(24, '2024_02_04_233606_add_user_id_to_orders', 9);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_amount` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `orders_user_id_foreign` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `customer_name`, `customer_address`, `total_amount`, `created_at`, `updated_at`, `user_id`) VALUES
(8, NULL, NULL, 950, '2024-02-04 18:14:55', '2024-02-04 18:14:55', 2),
(9, NULL, NULL, 950, '2024-02-04 18:17:56', '2024-02-04 18:17:56', 2);

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

DROP TABLE IF EXISTS `order_items`;
CREATE TABLE IF NOT EXISTS `order_items` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `order_id` bigint UNSIGNED NOT NULL,
  `item_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_items_order_id_foreign` (`order_id`),
  KEY `order_items_item_id_foreign` (`item_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `item_id`, `created_at`, `updated_at`) VALUES
(3, 8, 34, '2024-02-04 18:14:55', '2024-02-04 18:14:55'),
(4, 8, 33, '2024-02-04 18:14:55', '2024-02-04 18:14:55'),
(5, 8, 32, '2024-02-04 18:14:55', '2024-02-04 18:14:55'),
(6, 9, 34, '2024-02-04 18:17:56', '2024-02-04 18:17:56'),
(7, 9, 33, '2024-02-04 18:17:56', '2024-02-04 18:17:56'),
(8, 9, 32, '2024-02-04 18:17:56', '2024-02-04 18:17:56');

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
CREATE TABLE IF NOT EXISTS `password_reset_tokens` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE IF NOT EXISTS `personal_access_tokens` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `queries`
--

DROP TABLE IF EXISTS `queries`;
CREATE TABLE IF NOT EXISTS `queries` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `query` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `queries`
--

INSERT INTO `queries` (`id`, `name`, `email`, `query`, `created_at`, `updated_at`) VALUES
(1, 'muhammed jaseem', 'muhammed@gmail.com', 'do you have harry potter book', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `auth_token` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `auth_token`) VALUES
(1, 'Admin', 'admin@app.com', NULL, '$2y$12$MWC/Bug8UiO8wcWJ.2C9hOPVUcHbbuev6AnKkFJjnFJ/jPu03d7TW', NULL, '2024-01-31 07:37:39', '2024-01-31 07:37:39', NULL),
(2, 'jaseem', 'jaseem@gmail.com', NULL, '$2y$12$MWC/Bug8UiO8wcWJ.2C9hOPVUcHbbuev6AnKkFJjnFJ/jPu03d7TW', NULL, NULL, '2024-02-04 19:16:44', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwOi8vMTI3LjAuMC4xOjgwMDAvYXBpL2N1c3RvbWVyLWxvZ2luIiwiaWF0IjoxNzA3MDk0MDA0LCJleHAiOjE3MDcwOTc2MDQsIm5iZiI6MTcwNzA5NDAwNCwianRpIjoickhlbVVlUHNWNmY0azZIdCIsInN1YiI6IjIiLCJwcnYiOiIyM2JkNWM4OTQ5ZjYwMGFkYjM5ZTcwMWM0MDA4NzJkYjdhNTk3NmY3In0.HLZgDpuOtMSAdT0ZEaisBSNgdIqeWn1owXPATjzByao'),
(3, 'dsfsvaf', 'jaseemddd@gmail.com', NULL, '$2y$12$UPVKMbELEJ3Qf3N0OrIM1.MSulekw6oOkQq1CRlM2llLkgDQVCZWO', NULL, '2024-02-04 19:06:12', '2024-02-04 19:06:12', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwOi8vMTI3LjAuMC4xOjgwMDAvYXBpL2N1c3RvbWVyLXJlZ2lzdGVyIiwiaWF0IjoxNzA3MDkzMzcyLCJleHAiOjE3MDcwOTY5NzIsIm5iZiI6MTcwNzA5MzM3MiwianRpIjoicHZQYmFwZnNvNWw3WTl5ZSIsInN1YiI6IjMiLCJwcnYiOiIyM2JkNWM4OTQ5ZjYwMGFkYjM5ZTcwMWM0MDA4NzJkYjdhNTk3NmY3In0.aHBRQD0Naq77b3fPwfwJyfCWOFQKPiADmPf2g4r3ZDA');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
